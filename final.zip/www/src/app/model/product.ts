export class Product {
    id: number;
    brand: string;
    madeIn: string;
    model: string;
    price: number;
    screenSize: number;
    type: string;
    status: string;
}
