export class Brand {
    public id: number;
    public name: string;
}

export class Country {
    public id: number;
    public name: string;
}
